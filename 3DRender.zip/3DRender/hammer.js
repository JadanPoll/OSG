import  hammer from './hammer_real.js';
console.log(hammer)
export default hammer;