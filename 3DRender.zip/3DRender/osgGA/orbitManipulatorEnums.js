export default {
    ROTATE: 0,
    PAN: 1,
    ZOOM: 2
};
