import Text from '../osgText/Text.js';

var osgText = {};
osgText.Text = Text;

export default osgText;
