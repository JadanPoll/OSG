export default {
    ArrayType: Float64Array
};
