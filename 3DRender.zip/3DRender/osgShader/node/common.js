export default `
#define PI 3.141593
#define saturate(_x) clamp(_x, 0., 1.)
`