export default {
    RELATIVE_RF: 0,
    ABSOLUTE_RF: 1
};
