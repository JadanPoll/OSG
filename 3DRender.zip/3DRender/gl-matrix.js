import meglmatrix from './gl-matrix_real.js';
console.log("Nathan Hello World");
console.log(meglmatrix);
export default meglmatrix;
